import { create } from "zustand";

const helperUtils = create((set)=>({
  //Track learning of SignLanguage
  signLearning:-1,
  setSignLearning:(signLearning) => set({signLearning}),
  selfcareLearning:-1,//selfcare
  setSelfcareLearning:(selfcareLearning) => set({selfcareLearning}),
  softskilsLearning:-1,//softskils
  setSoftskillLearning:(softskilsLearning) => set({softskilsLearning}),

  tamilLearning:-1,//tamil
  setTamilLearning:(tamilLearning) => set({tamilLearning}),
  englishLearning:-1,//english
  setEnglishLearning:(englishLearning) => set({englishLearning}),
  mathsLearning:-1,//maths
  setMathsLearning:(mathsLearning) => set({mathsLearning}),
  scienceLearning:-1,//science
  setScienceLearning:(scienceLearning) => set({scienceLearning}),


}))

export default helperUtils;

