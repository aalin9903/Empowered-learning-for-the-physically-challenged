import React from 'react'

import helperUtils from '../../../utils/Helper'
import { content } from './EnvironmentContent'
import { ArrowRight , ArrowLeft } from 'lucide-react'
import EnvironmentalScienceIntro from './EnvironmentalIntro'
import EnvironmentalAssessment from './EnvironmentalAssesment'

const Environmental = () => {

    const {scienceLearning,setScienceLearning} = helperUtils();
    const contents = content();    

    const assesmentType =contents[scienceLearning];
    console.log(assesmentType+" this");
    console.log("sign learning :"+scienceLearning);
    
    
    
    
    

  return (
    <>
    {(scienceLearning===1 || scienceLearning ===3 || scienceLearning === 5 && scienceLearning!=-1) || scienceLearning == 8 ? <EnvironmentalAssessment assesmentType={assesmentType}/> :

    scienceLearning == -1 ? <EnvironmentalScienceIntro /> : 
    
    <div className="max-w-6xl mx-auto p-8 rounded-lg shadow-lg bg-yellow-50">
        <h1 className="text-4xl font-bold text-center text-blue-600 mb-6">
        {contents[scienceLearning][0].heading}
        </h1>
        <p className="text-lg text-center text-gray-700 mb-12">
        {contents[scienceLearning][1].description}
        </p>
        <div className="grid grid-cols-5 gap-6 sm:grid-cols-5 md:grid-cols-5 lg:grid-cols-5">
        {contents[scienceLearning].slice(2).map((alphabet) => (
            <div
            key={alphabet.contentType}
            className="group relative text-center bg-white rounded-lg shadow-md p-4 transform hover:scale-105 transition duration-300"
            >
            <img
                src={alphabet.url}
                alt={`Sign for ${alphabet.contentType}`}
                className="rounded-lg mb-4"
            />
            <h2 className="text-xl font-bold text-gray-800">
                {alphabet.topic}
            </h2>
            
            </div>
        ))}
        </div>
    </div>
    
    

}

    <div className='w-full h-40 px-5  items-center justify-center flex gap-80  '>
        {scienceLearning != -1 ?
        <button className='btn btn-primary w-56 text-white font-bold'
        onClick={()=>{setScienceLearning(scienceLearning-1)}}
        >
            <ArrowLeft/>
            PREVIOUS
        </button>
        :<></>}
        {scienceLearning <= 7 ? 
        <button className='btn btn-primary w-56 text-white font-bold'
        onClick={()=>{setScienceLearning(scienceLearning+1)}}
        >
            <ArrowRight/>
            NEXT
        </button>
        :<></>}
    </div>

    </>
  )
}

export default Environmental;