import React, { useState, useEffect } from 'react'
import Layout from '../components/Layout';
import { Book, Award, Star, Volume2, VolumeX } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import helperUtils from '../utils/Helper';

export const Home = () => {
  const [isSpeak, setIsSpeack] = useState(false);
  const [achievements, setAchievements] = useState({
    completedCourses: 0,
    totalBadges: 0,
    streak: 0,
    levelPercent :0,
    level:0
  });
  const navigate = useNavigate();

  // Get learning progress from helperUtils
  const {
    signLearning,
    selfcareLearning,
    softskilsLearning,
    tamilLearning,
    englishLearning,
    mathsLearning,
    scienceLearning
  } = helperUtils();

  // Update achievements whenever learning progress changes
  useEffect(() => {
    const calculateAchievements = () => {
      const allProgress = [
        signLearning,
        selfcareLearning,
        softskilsLearning,
        tamilLearning,
        englishLearning,
        mathsLearning,
        scienceLearning
      ];
      
 
      // Calculate total badges (1 per 25% progress in any course)
      const totalBadges = allProgress.reduce((sum, progress) => sum + Math.floor(progress / 1), 0) + 7;
            // Count completed courses (progress >= 100)
            const completedCourses = Math.floor(totalBadges/7);
      
      // Calculate streak (days with activity - would normally come from backend)
      const streak = Math.min(
        7 + Math.floor(completedCourses * 1.5), 
        30 // max streak
      );

    var levelPercent = totalBadges*10;
    var level =0;

    if(levelPercent>=100){
      level = levelPercent/100;
      levelPercent = levelPercent%100;
    }
      
      return {
        completedCourses,
        totalBadges,
        streak,
        levelPercent,
        level
      };
    };

    setAchievements(calculateAchievements());
  }, [signLearning, selfcareLearning, softskilsLearning, tamilLearning, 
      englishLearning, mathsLearning, scienceLearning]);

  // TEXT TO SPEECH
  const testSpeech = (text) => {
    if ("speechSynthesis" in window) {
      setIsSpeack(!isSpeak);

      const speech = new SpeechSynthesisUtterance(text);
      const voices = window.speechSynthesis.getVoices();
      
      const femaleVoice = voices.find(voice =>
        voice.name.includes("Female") || 
        voice.name.includes("Google UK English Female") || 
        voice.name.includes("Microsoft Zira")
      );

      if (femaleVoice) {
        speech.voice = femaleVoice;
      }

      speech.lang = "en-US";
      speech.rate = 1;
      speech.pitch = 1.2;

      if (!isSpeak) {
        window.speechSynthesis.speak(speech);
      } else {
        window.speechSynthesis.cancel();
      }
    } else {
      alert("Your browser does not support text-to-speech.");
    }
  };

  const handleRecommandation = (name) => {
    if (Recommendation === 0 && name === "GENERAL") setRecommendation(1);
    if (Recommendation === 0 && name === "FIRST STD") setRecommendation(2);
    
    const courseMap = {
      "english": "english",
      "Sign language": "signlanguage",
      "self care": "self care",
      "Soft skills": "softskills",
      "MATHEMATICS": "maths",
      "ENVIRONMENTAL SCIENCE": "ENVIRONMENTAL SCIENCE",
      "தமிழ்": "tamil"
    };

    if (courseMap[name]) {
      navigate("/learning", { state: courseMap[name] });
    }
  };

  // Recommendation data arrays
  const recommendation = [
    {
      name: "தமிழ்",
      comment: "குழநரதைகளின் உலகம் வண்ணமயமானது! விநரதைகள் பல நிரைநதைது!! அவரகளின் கறபரனத்திைன் கானுயிரகரையும் நட்புடன் நரட பயிலரவத்திடும். புதியன விரும்பும் அவரதைம் உற்ாக உள்ைம் அஃறிர்ணப்பபாருள்கரையும் அழகுதைமிழ் பபசிடச் ப்ய்திடும்.",
      url: "https://www.factsmostly.com/wp-content/uploads/2024/09/Tamil-Language.webp",
      tag1: "தமிழ்",
      tag2: "மொழி"
    },
    {
      name: "english",
      comment: "English is a West Germanic language in the Indo-European language family.",
      url: "https://www.vec.ca/wp-content/uploads/2019/03/English-Language-Level-System.jpg",
      tag1: "LANGUAGE",
      tag2: "IMPORTANTS"
    },
    {
      name: "MATHEMATICS",
      comment: "Mathematics is the study of numbers, shapes, and how they relate to each other.",
      url: "https://images.shiksha.com/mediadata/images/articles/1660038097phpGgaIzx.jpeg",
      tag1: "MATHS",
      tag2: "NUMBERS"
    },
    {
      name: "ENVIRONMENTAL SCIENCE",
      comment: "Environmental science is the study of the environment and how to protect it.",
      url: "https://carterwenthold.weebly.com/uploads/3/8/6/8/38681645/maxresdefault_orig.jpg",
      tag1: "NATURE",
      tag2: "WORLD"
    }
  ];

  const recommendation_main = [
    { 
      name: "Sign language", 
      comment: "A beautiful, expressive form of communication for the Deaf community", 
      url: "https://www.frederickinterpreting.com/wp-content/uploads/2021/04/asl.jpg", 
      tag1: "ESSENTIALS", 
      tag2: "LANGUAGE" 
    },
    { 
      name: "Soft skills", 
      comment: "Attributes describing how a person approaches tasks, valued in the workplace.", 
      url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRr3J5KO6PLfSyZWPfy489PW70XfdcdT6QHBg&s",
      tag1: "SOCIAL",
      tag2: "COMMUNICATION"
    },
    { 
      name: "self care", 
      comment: "Fosters independence through hygiene, nutrition, and rest.", 
      url: "https://i.pinimg.com/736x/ea/10/b2/ea10b24e5c2f67fdf497999a67fc8c29.jpg",
      tag1: "SELF-LOVE",
      tag2: "LIFE-STYLE"
    }
  ];

  const common = [
    { 
      name: "GENERAL", 
      comment: "Courses that empower people with disabilities by teaching essential skills.", 
      url: "https://www.inclusionhub.com/hubfs/Blog/disabled-people-in-park-setting-1.jpg", 
      tag1: "COMMON", 
      tag2: "LIFE-STYLE" 
    },
    { 
      name: "FIRST STD", 
      comment: "Courses helping first-grade children with disabilities learn essential skills.", 
      url: "https://core-docs.s3.amazonaws.com/genoa-kingston_cusd_%23424_ar/article/image/large_04a9ded7-edf4-48f6-ad29-f94f3b8ba7f3.jpg", 
      tag1: "LEARN", 
      tag2: "KNOWLWDGE" 
    }
  ];

  const Recommend = [common, recommendation_main, recommendation];
  const [Recommendation, setRecommendation] = useState(0);

  return (
    <Layout>
      <div className="space-y-8 h-full">
        {/* Welcome Section */}
        <section className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h1 className="text-2xl font-bold mb-4">Welcome back</h1>
          <div className="flex items-center space-x-4">
            <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
              <span className="text-2xl">👋</span>
            </div>
            <div>
              <p className="text-lg">Continue your learning journey</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Level {Math.floor(achievements.level)} • 
                {achievements.levelPercent}% to next level
              </p>
            </div>
          </div>
        </section>

        {/* Progress Dashboard */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Current Course */}
          <div 
            className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm hover:shadow-xl transition-all cursor-pointer"
            onClick={() => Recommendation >= 1 ? setRecommendation(0) : null}
          >
            <div className="flex items-center space-x-3 mb-4">
              <Book className="h-6 w-6 text-blue-500" />
              <h2 className="text-lg font-semibold">Current Course</h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400">
              {achievements.completedCourses > 0 ? 
                `${achievements.completedCourses} completed` : 
                'Start your first course'}
            </p>
            <div className="mt-4 bg-gray-200 dark:bg-gray-700 rounded-full h-2">
              <div 
                className="bg-blue-500 h-2 rounded-full transition-all duration-300" 
                style={{ 
                  width: `${Math.max(
                    5, 
                    (achievements.completedCourses / 7) * 100
                  )}%` 
                }} 
              />
            </div>
          </div>

          {/* Achievements */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm hover:shadow-xl transition-all">
            <div className="flex items-center space-x-3 mb-4">
              <Award className="h-6 w-6 text-purple-500" />
              <h2 className="text-lg font-semibold">Achievements</h2>
            </div>
            <p className="text-3xl font-bold">{achievements.totalBadges}</p>
            <p className="text-gray-600 dark:text-gray-400">Badges earned</p>
          </div>

          {/* Daily Streak */}
          <div className="bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm hover:shadow-xl transition-all">
            <div className="flex items-center space-x-3 mb-4">
              <Star className="h-6 w-6 text-yellow-500" />
              <h2 className="text-lg font-semibold">Daily Streak</h2>
            </div>
            <p className="text-3xl font-bold">{achievements.streak}</p>
            <p className="text-gray-600 dark:text-gray-400">Days in a row</p>
          </div>
        </section>

        {/* Recommended Modules */}
        <section className="h-full bg-white dark:bg-gray-800 rounded-lg p-6 shadow-sm">
          <h2 className="text-xl font-semibold mb-4">Recommended for You</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {Recommend[Recommendation].map((item, index) => (
              <div 
                key={index} 
                className="card bg-white w-full hover:shadow-xl transition-all border dark:bg-gray-700 dark:text-white dark:border-gray-600"
              >
                <figure 
                  className="cursor-pointer"
                  onClick={() => handleRecommandation(item.name)}
                >
                  <img
                    src={item.url}
                    alt={item.name}
                    className="w-full h-48 object-cover rounded-t-lg"
                  />
                </figure>
                <div 
                  className="card-body p-4 cursor-pointer"
                  onClick={() => handleRecommandation(item.name)}
                >
                  <h2 className="card-title text-lg">
                    {item.name}
                    <div className="badge badge-secondary ml-2">NEW</div>
                  </h2>
                  <p className="text-sm mt-2">{item.comment}</p>
                  <div className="card-actions justify-end mt-4">
                    <div className="badge badge-outline">{item.tag1}</div>
                    <div className="badge badge-outline">{item.tag2}</div>
                  </div>
                </div>
                
                <div className='p-2 flex justify-center'>
                  <button 
                    onClick={() => isSpeak ? testSpeech() : testSpeech(item.comment)}
                    className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                  >
                    {!isSpeak ? 
                      <Volume2 className="h-5 w-5" /> : 
                      <VolumeX className="h-5 w-5" />
                    }
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </Layout>
  );
};